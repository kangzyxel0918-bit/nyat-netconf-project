
from nyat.xml_utils import load_xml_file, get_data_ele
from nyat.report import record_test_time

NS = {"acl": "urn:ietf:params:xml:ns:yang:ietf-access-control-list"}

def _assert_acl_state(reply, want_dest=None, want_src=None, want_forwarding=None):
    data = get_data_ele(reply)
    assert data is not None, "No <data> in reply"
    acl_nodes = data.xpath("//acl:acls/acl:acl[acl:name='NETCONF_acl']", namespaces=NS)
    assert acl_nodes, "ACL NETCONF_acl not found"
    ace_nodes = data.xpath("//acl:acls/acl:acl[acl:name='NETCONF_acl']/acl:aces/acl:ace[acl:name='NETCONF_acl']",
                           namespaces=NS)
    if want_dest is None and want_src is None:
        pass
    else:
        assert ace_nodes, "ACE NETCONF_acl not found"
    dest = data.xpath("//acl:acls/acl:acl[acl:name='NETCONF_acl']/acl:aces/acl:ace[acl:name='NETCONF_acl']/acl:matches/acl:eth/acl:destination-mac-address", namespaces=NS)
    src  = data.xpath("//acl:acls/acl:acl[acl:name='NETCONF_acl']/acl:aces/acl:ace[acl:name='NETCONF_acl']/acl:matches/acl:eth/acl:source-mac-address", namespaces=NS)
    fwd  = data.xpath("//acl:acls/acl:acl[acl:name='NETCONF_acl']/acl:aces/acl:ace[acl:name='NETCONF_acl']/acl:actions/acl:forwarding", namespaces=NS)
    dest_txt = dest[0].text if dest else None
    src_txt  = src[0].text if src else None
    fwd_txt  = fwd[0].text if fwd else None
    if want_dest is not None: assert dest_txt == want_dest, f"dest-mac mismatch: {dest_txt}"
    if want_src  is not None: assert src_txt  == want_src,  f"src-mac mismatch: {src_txt}"
    if want_forwarding is not None:
        assert fwd_txt in (want_forwarding, f"acl:{want_forwarding}"), f"forwarding mismatch: {fwd_txt}"

@record_test_time
def test_acl_create_drop_dest_ok(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/acl-edit-initial-drop.rpc.xml"))
    assert "ok" in reply.xml, "No <ok/> for initial edit-config"

@record_test_time
def test_acl_get_config_verify_drop(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/acl-get-config.rpc.xml"))
    _assert_acl_state(reply, want_dest="ac:12:22:88:d2:2a", want_src=None, want_forwarding="drop")

@record_test_time
def test_acl_get_verify_drop(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/acl-get.rpc.xml"))
    _assert_acl_state(reply, want_dest="ac:12:22:88:d2:2a", want_src=None, want_forwarding="drop")

@record_test_time
def test_acl_merge_source_accept_ok(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/acl-merge-source-accept.rpc.xml"))
    assert "ok" in reply.xml, "No <ok/> for merge source-mac"

@record_test_time
def test_acl_get_config_verify_both_macs_accept(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/acl-get-config.rpc.xml"))
    _assert_acl_state(reply, want_dest="ac:12:22:88:d2:2a", want_src="55:12:66:ac:12:1d", want_forwarding="accept")

@record_test_time
def test_acl_get_verify_both_macs_accept(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/acl-get.rpc.xml"))
    _assert_acl_state(reply, want_dest="ac:12:22:88:d2:2a", want_src="55:12:66:ac:12:1d", want_forwarding="accept")

@record_test_time
def test_acl_remove_source_ok(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/acl-remove-source.rpc.xml"))
    assert "ok" in reply.xml, "No <ok/> for remove source-mac"

@record_test_time
def test_acl_get_config_verify_source_removed(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/acl-get-config.rpc.xml"))
    _assert_acl_state(reply, want_dest="ac:12:22:88:d2:2a", want_src=None, want_forwarding="accept")

@record_test_time
def test_acl_delete_ace_ok(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/acl-delete-ace.rpc.xml"))
    assert "ok" in reply.xml, "No <ok/> for delete ACL"

@record_test_time
def test_acl_get_config_verify_deleted(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/acl-get-config.rpc.xml"))
    data = get_data_ele(reply)
    assert data is not None, "No <data> in get-config reply"
    acl_nodes = data.xpath("//acl:acls/acl:acl[acl:name='NETCONF_acl']", namespaces=NS)
    assert not acl_nodes, "ACL NETCONF_acl still present after delete"
