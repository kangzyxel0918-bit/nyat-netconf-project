
from nyat.xml_utils import load_xml_file, get_data_ele
from nyat.report import record_test_time

NS = {"sys": "urn:ietf:params:xml:ns:yang:ietf-system"}

def _first_text(data, path):
    nodes = data.xpath(path, namespaces=NS)
    return nodes[0].text if nodes else None

def _assert_values(data, contact=None, hostname=None, location=None):
    assert data is not None, "No <data> in reply"
    if contact is None and hostname is None and location is None:
        # expecting empty <data/>
        assert len(data) == 0, f"Expected empty <data/>, got: {len(data)} child nodes"
        return
    if contact is not None:
        assert _first_text(data, "//sys:system/sys:contact") == contact, "contact mismatch"
    if hostname is not None:
        assert _first_text(data, "//sys:system/sys:hostname") == hostname, "hostname mismatch"
    if location is not None:
        assert _first_text(data, "//sys:system/sys:location") == location, "location mismatch"

@record_test_time
def test_01_edit_config_ok(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/system-edit-config.rpc.xml"))
    assert "ok" in reply.xml

@record_test_time
def test_02_get_config_verify_initial(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/system-get-config.rpc.xml"))
    data = get_data_ele(reply)
    _assert_values(data, contact="NETCONF_contacttest", hostname="NETCONF_hostname", location="NETCONF_location")

@record_test_time
def test_03_get_verify_initial(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/system-get.rpc.xml"))
    data = get_data_ele(reply)
    _assert_values(data, contact="NETCONF_contacttest", hostname="NETCONF_hostname", location="NETCONF_location")

@record_test_time
def test_04_merge_ok(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/system-merge.rpc.xml"))
    assert "ok" in reply.xml

@record_test_time
def test_05_get_config_verify_merge(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/system-get-config.rpc.xml"))
    data = get_data_ele(reply)
    _assert_values(data, contact="NETCONF_contact_mer", hostname="NETCONF_hostname_mer", location="NETCONF_location_mer")

@record_test_time
def test_06_get_verify_merge(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/system-get.rpc.xml"))
    data = get_data_ele(reply)
    _assert_values(data, contact="NETCONF_contact_mer", hostname="NETCONF_hostname_mer", location="NETCONF_location_mer")

@record_test_time
def test_07_remove_ok(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/system-remove.rpc.xml"))
    assert "ok" in reply.xml

@record_test_time
def test_08_get_config_expect_empty(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/system-get-config.rpc.xml"))
    data = get_data_ele(reply)
    _assert_values(data)  # expect empty

@record_test_time
def test_09_get_expect_empty(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/system-get.rpc.xml"))
    data = get_data_ele(reply)
    _assert_values(data)  # expect empty

@record_test_time
def test_10_recreate_ok(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/system-recreate.rpc.xml"))
    assert "ok" in reply.xml

@record_test_time
def test_11_delete_fields_ok(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/system-delete-fields.rpc.xml"))
    assert "ok" in reply.xml

@record_test_time
def test_12_get_config_expect_empty_again(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/system-get-config.rpc.xml"))
    data = get_data_ele(reply)
    _assert_values(data)  # expect empty

@record_test_time
def test_13_get_expect_empty_again(netconf):
    reply = netconf.rpc_any(load_xml_file("nyat/yang/system-get.rpc.xml"))
    data = get_data_ele(reply)
    _assert_values(data)  # expect empty
