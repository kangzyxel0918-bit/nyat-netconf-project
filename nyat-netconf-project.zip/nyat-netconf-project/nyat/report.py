
import time, logging, functools
try:
    import allure
except Exception:
    allure = None

logger = logging.getLogger(__name__)

def record_test_time(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        try:
            return func(*args, **kwargs)
        except Exception as e:
            logger.exception(f"Test failed: {func.__name__}: {e}")
            if allure:
                try:
                    allure.attach(str(e), name="exception", attachment_type=allure.attachment_type.TEXT)
                except Exception:
                    pass
            raise
        finally:
            dur = time.time() - start
            logger.info(f"[NYAT] %s took %.3fs", func.__name__, dur)
            if allure:
                try:
                    allure.attach(f"{dur:.3f}s", name="duration", attachment_type=allure.attachment_type.TEXT)
                except Exception:
                    pass
    return wrapper
