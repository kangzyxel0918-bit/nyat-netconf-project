
from lxml import etree

NC_NS = "urn:ietf:params:xml:ns:netconf:base:1.0"

def load_xml_file(path: str):
    with open(path, "rb") as f:
        return etree.fromstring(f.read())

def pretty_xml(elem) -> str:
    return etree.tostring(elem, pretty_print=True, encoding="unicode")

def get_data_ele(reply):
    xml = getattr(reply, "xml", None)
    if xml is None:
        xml = str(reply)
    root = etree.fromstring(xml.encode("utf-8"))
    data = root.find(f".//{{{NC_NS}}}data")
    return data
