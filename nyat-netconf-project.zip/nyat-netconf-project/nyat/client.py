
from __future__ import annotations
from typing import Optional, Union
import logging
from contextlib import contextmanager
from lxml import etree
from ncclient import manager
from ncclient.operations import RPCError
from nyat.xml_utils import pretty_xml
try:
    import allure
except Exception:
    allure = None

logger = logging.getLogger(__name__)

class NetconfClient:
    def __init__(self, device_cfg: dict, log_level: str = "INFO"):
        logging.basicConfig(
            level=getattr(logging, log_level.upper(), logging.INFO),
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        )
        self.device_cfg = device_cfg
        self.m: Optional[manager.Manager] = None

    def connect(self):
        host = self.device_cfg.get("host")
        port = int(self.device_cfg.get("port", 830))
        username = self.device_cfg.get("username")
        password = self.device_cfg.get("password")
        timeout = int(self.device_cfg.get("timeout", 30))
        if host is None or username is None or password is None:
            raise ValueError("Config error: host/username/password 皆不可為空，請檢查 config.yaml")
        host = str(host); username = str(username); password = str(password)
        params = {
            "host": host, "port": port, "username": username, "password": password,
            "allow_agent": bool(self.device_cfg.get("allow_agent", False)),
            "look_for_keys": bool(self.device_cfg.get("look_for_keys", False)),
            "hostkey_verify": bool(self.device_cfg.get("hostkey_verify", False)),
            "timeout": timeout,
            "device_params": self.device_cfg.get("device_params", {"name": "default"}),
        }
        logger.info(f"Connecting to NETCONF server {host}:{port} ...")
        self.m = manager.connect(**params)
        logger.info("Connected. Server capabilities: %d items.", len(self.m.server_capabilities))

    def close(self):
        if self.m is not None:
            self.m.close_session()
            logger.info("NETCONF session closed.")
            self.m = None

    def get(self, filter_xml: Union[str, etree._Element] = None):
        if isinstance(filter_xml, str):
            filter_xml = etree.fromstring(filter_xml.encode("utf-8"))
        return self.m.get(filter=("subtree", filter_xml)) if filter_xml is not None else self.m.get()

    def get_config(self, source: str = "running", filter_xml: Union[str, etree._Element] = None):
        if isinstance(filter_xml, str):
            filter_xml = etree.fromstring(filter_xml.encode("utf-8"))
        return self.m.get_config(source=source, filter=("subtree", filter_xml) if filter_xml is not None else None)

    def edit_config(self, target: str, config_xml: Union[str, etree._Element], default_operation=None):
        if isinstance(config_xml, str):
            config_xml = etree.fromstring(config_xml.encode("utf-8"))
        return self.m.edit_config(target=target, config=config_xml, default_operation=default_operation)

    def rpc(self, rpc_xml: Union[str, etree._Element]):
        if isinstance(rpc_xml, str):
            rpc_xml = etree.fromstring(rpc_xml.encode("utf-8"))
        try:
            return self.m.dispatch(rpc_xml)
        except RPCError as e:
            logger.error("RPCError: %s", e)
            raise

    def rpc_any(self, rpc_or_op_xml: Union[str, etree._Element]):
        if isinstance(rpc_or_op_xml, str):
            elem = etree.fromstring(rpc_or_op_xml.encode("utf-8"))
        else:
            elem = rpc_or_op_xml
        ns_nc = "urn:ietf:params:xml:ns:netconf:base:1.0"
        if isinstance(elem.tag, str) and elem.tag.endswith('rpc') and (ns_nc in elem.tag):
            inner = next((c for c in elem if isinstance(c.tag, str)), None)
            if inner is None:
                raise ValueError("Empty <rpc> element: no operation found")
            op = inner
        else:
            op = elem

        if allure:
            try:
                allure.attach(pretty_xml(elem), name="NETCONF Request", attachment_type=allure.attachment_type.XML)
            except Exception:
                pass

        try:
            reply = self.m.dispatch(op)
            if allure:
                try:
                    from lxml import etree as _et
                    allure.attach(pretty_xml(_et.fromstring(reply.xml.encode("utf-8"))),
                                  name="NETCONF Reply",
                                  attachment_type=allure.attachment_type.XML)
                except Exception:
                    pass
            return reply
        except RPCError as e:
            if allure:
                try:
                    allure.attach(str(e), name="NETCONF RPCError", attachment_type=allure.attachment_type.TEXT)
                except Exception:
                    pass
            logger.error("RPCError: %s", e)
            raise

    @contextmanager
    def candidate(self, confirmed: bool=False, timeout: int=60):
        self.m.lock("candidate")
        try:
            if confirmed:
                self.m.commit(confirmed=True, timeout=timeout)
            yield
            self.m.commit()
        finally:
            self.m.unlock("candidate")
