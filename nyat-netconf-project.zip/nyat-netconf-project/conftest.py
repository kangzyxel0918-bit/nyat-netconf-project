
import pytest
from nyat.config import load_config
from nyat.client import NetconfClient

def pytest_addoption(parser):
    parser.addoption("--config", action="store", default="config/config.yaml",
                     help="Path to YAML config file")

@pytest.fixture(scope="session")
def cfg(pytestconfig):
    return load_config(pytestconfig.getoption("--config"))

@pytest.fixture(scope="session")
def netconf(cfg: dict):
    client = NetconfClient(cfg.get("device", {}), log_level=cfg.get("logging", {}).get("level", "INFO"))
    client.connect()
    yield client
    client.close()
